package Concesionaria;

import java.text.DecimalFormat;


public class Moto extends Vehiculo {

	private static final DecimalFormat df = new DecimalFormat("#,##0.00");
	public int cilindrada;
	
	
	public Moto (String marca, String modelo, double precio, int cilindrada) {
		super (marca, modelo, precio);
		this.cilindrada = cilindrada;
	}
	
	public int getCilindrada() {
		return cilindrada;
	}

	public void setCilindrada(int cilindrada) {
		this.cilindrada = cilindrada;
	}
	
	
	public void mostrarDatos() { 
		System.out.println("Marca: " + getMarca() +  " // Modelo: " + getModelo() + " // " + "Cilindrada: " + getCilindrada() + "c // Precio: $" + df.format(super.getPrecio()));
	}
}
