package Concesionaria;

import java.text.DecimalFormat;

public class Auto  extends Vehiculo{

	public int puertas;
	
	private static final DecimalFormat df = new DecimalFormat("#,##0.00");
	
	public Auto (String marca, String modelo, double precio, int puertas) {
		super (marca, modelo, precio);
		this.puertas = puertas;
	}

	public int getPuertas() {
		return puertas;
	}

	public void setPuertas(int puertas) {
		this.puertas = puertas;
	}
	
	public void mostrarDatos() {
	 System.out.println("Marca: " + getMarca() +  " // Modelo: " + getModelo() + " // " + "Puertas: " + getPuertas() + " // Precio: $" + df.format(super.getPrecio()));
		
	}
}
