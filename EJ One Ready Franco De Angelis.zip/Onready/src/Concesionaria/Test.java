package Concesionaria;

import java.text.DecimalFormat;
import java.util.ArrayList;


public class Test {
	private static final DecimalFormat df = new DecimalFormat("#,##0.00");
	static ArrayList<Vehiculo> autos = new ArrayList<Vehiculo>();
	public static void main(String[] args) {
	
		crearAutos();
	
		
		mostrarLista();
		
		System.out.println("===============================");
		
		 mostrarMasCaro();
		 mostrarMasBarato();
		 contain();
		 
		 System.out.println("===============================");
		 
		 mostrarOrdenadosPorPrecio();
	}
	
	/* Todo lo hice usando mis conocimientos adquiridos en mi facultad.
		Siguiendo las normas que me ense�aban, como por ejemplo:
		NO MODIFICAR EL TO STRING
		no se si estoy en lo cierto pero sabiendo eso, cree varios metodos para las impresiones.
		
		PD: Aclaro estas peque�as cosas por si ven algo raro en mi codigo. Pero al final, cumple con las consignas.
		
		MUCHAS GRACIAS!
		*/

	public static void contain() {
		Vehiculo b = null;
		for(int i = 0; i<autos.size();i++) {
			Vehiculo a = autos.get(i);
			if(a.getModelo().contains("Y")) {
				b=a;
			}
		}
		System.out.println("Vehiculo que contiene en el modelo la letra 'Y': " + b.getMarca() + " " + b.getModelo() + " $"+ df.format(b.getPrecio()));
	
	}

	public static void mostrarLista() {
		for(int i = 0; i<autos.size();i++) {
			Vehiculo a = autos.get(i);
			a.mostrarDatos();
		}
	}
	
	public static void mostrarMarcaMod() {
		for(int i = 0; i<autos.size();i++) {
			Vehiculo a = autos.get(i);
			System.out.println(a.getMarca() + " " + a.getModelo());
		}
	}
	
	public static void mostrarMasCaro(){
        Vehiculo mayor = autos.get(0);
        for(int i = 0; i < autos.size(); i++){
            if(autos.get(i).getPrecio() > mayor.getPrecio()) {
                mayor = autos.get(i);
        }
        }
        System.out.println("Vehiculo m�s caro: " + mayor.getMarca() + " "+ mayor.getModelo());
    }
	
	public static void mostrarMasBarato(){
        Vehiculo menor = autos.get(0);
        
        for(int i = 0; i < autos.size(); i++){
            if(autos.get(i).getPrecio() < menor.getPrecio()) {
                menor = autos.get(i);
        }
        }
        System.out.println("Vehiculo m�s barato: " + menor.getMarca() + " "+ menor.getModelo());
    }
	
	public static void mostrarOrdenadosPorPrecio(){
        int i, j;
        Vehiculo aux;
        for(i = 0; i< autos.size()-1; i++)
            for(j=0;j<autos.size()-i-1; j++)
                if(autos.get(j+1).getPrecio() > autos.get(j).getPrecio()){
                    aux = autos.get(j+1);
                    autos.set(j+1, autos.get(j));
                    autos.set(j, aux);                
                }
        mostrarMarcaMod();
    }

	private static void crearAutos() {
			autos.add(new Auto("Peugeot", "206", 200000, 4));
			autos.add(new Moto("Honda", "Titan",60000, 125));
			autos.add(new Auto("Peugeot", "208", 250000, 5));
			autos.add(new Moto("Yamaha", "YBR",80500.5 , 160));
			
		}
}
